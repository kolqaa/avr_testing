#include "main.h"

buffer_t buffer;

ISR(USART0_UDRE_vect) {
  if (!bufferIsEmpty(&buffer))
    UDR0 = popFromBuff(&buffer);
  else
    UCSR0B &= ~_BV(UDRIE0);
}

void init_port(void) {
  DDRB |= _BV(PB7);
  DDRD &= ~(_BV(PD1));
  DDRD &=  ~(_BV(PD0));

  PORTD |= (_BV(PD1));
  PORTD |= (_BV(PD0));
  PORTB &= ~(_BV(PB7));
}

int	main(void) {  
  cli();
  
  init_port();
  init_buffer(&buffer, BUFF_SIZE);
  init_uart();
  TWI_init();

  sei();
  init_bh1750_lightSensor();
  while (1) {
    uint16_t lux = getlux_from_bh1750_lightSensor();
    
    u_printnumbers(lux);
    u_print("[lx]\n");
    
    if (!bufferIsEmpty(&buffer))
      UCSR0B |= _BV(UDRIE0);
    _delay_ms(500);
  }
  
  return (0);
}
